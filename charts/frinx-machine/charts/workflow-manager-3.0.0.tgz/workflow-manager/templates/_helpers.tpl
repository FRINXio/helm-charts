{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "workflow-manager.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "workflow-manager.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "workflow-manager.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "workflow-manager.labels" -}}
helm.sh/chart: {{ include "workflow-manager.chart" . }}
{{ include "workflow-manager.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "workflow-manager.selectorLabels" -}}
app.kubernetes.io/name: {{ include "workflow-manager.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "workflow-manager.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "workflow-manager.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get the password secret.
*/}}
{{- define "workflow-manager.secretName" -}}
{{- if .Values.dbPersistence.existingSecret.secretName }}
    {{- printf "%s" (tpl .Values.dbPersistence.existingSecret.secretName $) -}}
{{- else -}}
    {{- printf "%s" (include "workflow-manager.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return true if a secret object should be created
*/}}
{{- define "workflow-manager.createSecret" -}}
{{- if not .Values.dbPersistence.existingSecret.secretName -}}
    {{- true -}}
{{- end -}}
{{- end -}}


{{/*
Get the password secret.
*/}}
{{- define "workflow-manager.schellarSecretName" -}}
{{- if .Values.schellarDbPersistence.existingSecret.secretName }}
    {{- printf "%s" (tpl .Values.schellarDbPersistence.existingSecret.secretName $) -}}
{{- else -}}
    {{- printf "%s-schellar" (include "workflow-manager.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return true if a secret object should be created
*/}}
{{- define "workflow-manager.createSchellarSecret" -}}
{{- if not .Values.schellarDbPersistence.existingSecret.secretName -}}
    {{- true -}}
{{- end -}}
{{- end -}}